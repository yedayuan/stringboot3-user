package com.example.boot3.users.Entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import io.swagger.annotations.ApiModel;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author 叶大源
 * @since 2023-07-18
 */


@Data
@TableName(value = "user")
@ApiModel("用户实体类")
public class User implements Serializable {

    private static final long serialVersionUID = 1L;


    @TableId(value = "id", type = IdType.AUTO)
    private Long id;/*主键ID*/
    @TableField(exist = false)
    private String username; /**用户*/


    @TableField(exist = false)
    private String name;/*姓名*/

    @TableField(exist = false ,select = false)
    private String password;/*密码*/
    @TableField(exist = false)

    private Integer gender;/*性别*/

    @TableField(exist = false)
    private Integer age; /*年龄*/


    @TableField(exist = false)
    private LocalDate entrydate;//入职时间

    @TableField(exist = false)
    private LocalDateTime begindate;//入职开始时间
    @TableField(exist = false)
    private LocalDateTime enddate;//入职结束时间
    @TableField(exist = false)
    private String email;/*邮箱*/
    @TableField(exist = false)
    private Integer status; /*状态0可用,1锁定*/
    /*创建人id*/
    @TableField(exist = false)
   private long createid;
    /*修改人id*/
    @TableField(exist = false)
   private long updateid;
}
